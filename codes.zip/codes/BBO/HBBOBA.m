function [x,y,z,kp,ki,kd,fbbo,fba]=HBBOBA(MaxItbbo,MaxItba)
kp=rand;
ki=rand;
kd=rand;
[kp,ki,kd,fbbo]=BBO(kp,ki,kd,MaxItbbo);
minkp=kp-kp/2;
maxkp=kp+kp/2;
 
minki=ki-ki/2;
maxki=ki+ki/2;
 
minkd=kd-kd/2;
maxkd=kd+kd/2;

x = unifrnd(minkp, maxkp, 1);
y= unifrnd(minki, maxki, 1);
z= unifrnd(minkd, maxkd, 1);

%x=kp;
%y=ki;
%z=kd;
[kp,ki,kd,fba]=BA(x,y,z,MaxItba);

end