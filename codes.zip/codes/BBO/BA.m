function [kp,ki,kd,fba]=BA(kp,ki,kd,MaxIt)
 minkp=kp-rand;
 maxkp=kp+rand;
 
 minki=ki-rand;
 maxki=ki+rand;
 
 minkd=kd-rand;
 maxkd=kd+rand;

%% Problem Definition
CostFunction=@(x) PID_objective(x);        % Cost Function
nVar=3;             % Number of Decision Variables
VarSize=[1 nVar];   % Decision Variables Matrix Size
VarMin=-10;         % Decision Variables Lower Bound
VarMax= 10;         % Decision Variables Upper Bound
%% Bees Algorithm Parameters
%MaxIt=1000;          % Maximum Number of Iterations
nScoutBee=5;                   % Number of Scout Bees
nBee0=round(0.3*nScoutBee);     % Recruited Bees Scale
r=0.1*(VarMax-VarMin);	% Neighborhood Radius
rdamp=0.95;             % Neighborhood Radius Damp Rate
%% Initialization
% Empty Bee Structure
empty_bee.Position=[];
empty_bee.Cost=[];
% Initialize Bees Array
bee=repmat(empty_bee,nScoutBee,1);
% Create New Solutions
for i=1:nScoutBee
   % bee(i).Position(1) = unifrnd(minkp, maxkp, 1);
   % bee(i).Position(2) = unifrnd(minki, maxki, 1);
   % bee(i).Position(3) = unifrnd(minkd, maxkd, 1);
    bee(i).Position(1) = kp;
    bee(i).Position(2) = ki;
    bee(i).Position(3) = kd;
    bee(i).Cost=CostFunction(bee(i).Position);
end
% Sort
[~, SortOrder]=sort([bee.Cost]);
bee=bee(SortOrder);
% Update Best Solution Ever Found
BestSol=bee(1);
% Array to Hold Best Cost Values
BestCost=zeros(MaxIt,1);
%% Bees Algorithm Main Loop
for it=1:MaxIt
    
    F=1./[bee.Cost];
    d=F/mean(F);
    
    for i=1:nScoutBee
        
        if d(i)<0.9
            pReject=0.6;
            
        elseif d(i)>=0.9 && d(i)<0.95
            pReject=0.2;
            
        elseif d(i)>=0.95 && d(i)<1.15
            pReject=0.05;
            
        elseif d(i)>=1.15
            pReject=0;
            
        end
        
        if rand>=pReject
            % Accept
            nBee=ceil(nBee0*d(i));
            
            bestnewbee.Cost=inf;
            for j=1:nBee
                newbee.Position=PerformBeeDance(bee(i).Position,r);
                newbee.Cost=CostFunction(newbee.Position);
                if newbee.Cost<bestnewbee.Cost
                    bestnewbee=newbee;
                end
            end
            if bestnewbee.Cost<bee(i).Cost
                bee(i)=bestnewbee;
            end
            
       else
            % Reject
            bee(i).Position(1)=unifrnd(kp-(kp/2),kp+(kp/2),1);
            bee(i).Position(2)=unifrnd(ki-(ki/2),ki+(ki/2),1);
            bee(i).Position(3)=unifrnd(kd-(kd/2),kd+(kd/2),1);
            bee(i).Cost=CostFunction(bee(i).Position);
        end
         % Apply Lower and Upper Bound Limits
        bee(i).Position = max(bee(i).Position, 0);
       
        
    end
    
    % Sort
    [~, SortOrder]=sort([bee.Cost]);
    bee=bee(SortOrder);
    
    % Update Best Solution Ever Found
    BestSol=bee(1);
    
    % Store Best Cost Ever Found
    BestCost(it)=BestSol.Cost;
    
    % Display Iteration Information
    disp(['Iteration BA ' num2str(it) ': Best Cost = ' num2str(BestCost(it))]);
    
    % Damp Neighborhood Radius
    r=r*rdamp;
    
end
%% Results
figure;
%plot(BestCost,'LineWidth',2);
semilogy(BestCost,'LineWidth',2);
xlabel('Iteration');
ylabel('Best Cost');
grid on;
fba=BestCost;
kp=bee(1).Position(1);
ki=bee(1).Position(2);
kd=bee(1).Position(3);
end
