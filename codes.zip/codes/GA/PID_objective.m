function J=PID_objective(x)
s=tf('s');
plant1=tf(9.4223,[9.998e-4 8.2346]);
plant2=tf(1,[1 7.56 6.892]);
plant=plant1*plant2;
cont=x(1)+x(2)/s+x(3).*s;
y=feedback(cont*plant,1);


dt=0.1;
t=0:dt:10;
u=sin((pi/5)*t);
q=lsim(y,u,t);
p=q';
e=u-p;

%J=sum(t'.*abs(e).*dt);
%J=sum(abs(e)*dt);
%J=sum(abs(e));
%J= trapz(t, t'.*abs(e));
J= trapz(t,abs(e));
end