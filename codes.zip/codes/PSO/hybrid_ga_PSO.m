function [kp,ki,kd,x,y,z,fval,fpso]=hybrid_ga_PSO(initpop,gen,MaxIt)

[x,y,z,fval]=PID_ga(initpop,gen);
[kp,ki,kd,fpso]=pso(x,y,z,MaxIt);

%j=1:gen;
  %  plot(j,fval,'.')
 %   hold on
 % k=gen+1:MaxIt+gen;
 %  plot(k,fpso,'.')
   
end

