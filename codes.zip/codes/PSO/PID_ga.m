function [k_p,k_i,k_d,fval]=PID_ga(initpop,gen)

opts=optimoptions('ga','PopulationSize',20,'Display','iter','Generations',gen,'InitialPopulation',initpop,...
    'PlotFcns',@myplot);
x=ga(@(x) PID_objective(x),3,[],[],[],[],[0 0 0],[6 10 0.5],[],opts);


 % simple plot function
    function state= myplot(options,state,flag)
        fval=state.Best';
        disp(state.Population);
       
    end
k_p=x(1);
k_i=x(2);
k_d=x(3); 
end