function J=PID_objective(x)
s=tf('s');
%plant=tf(26.4499,[0.001,0.2362,1.0606,4.6603]);
plant=tf(25.9909,[0.001,0.0641,0.5658,1.7326]);
%plant2=tf(1,[1 3.165 15.65]);
%plant=plant1*plant2;
cont=x(1)+x(2)/s+x(3).*s;
%y=feedback(cont*plant,1);


%dt=0.1;
%t=0:dt:10;
%u=sin((pi/5)*t);
%q=lsim(y,u,t);
%p=q';
%e=u-p;


%step(feedback(cont*plant,1));
dt=0.01;
t=0:dt:1;
e=1-step(feedback(cont*plant,1),t);


J=sum(t'.*abs(e).*dt);
%J=sum(abs(e)*dt);
%J=sum(abs(e));
%J= trapz(t, t'.*abs(e));
%J= trapz(t,abs(e));
end