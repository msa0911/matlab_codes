function [kp,ki,kd,fpso]=pso(kp,ki,kd,MaxIt)

%% problem Defenition

 CostFunction = @(x) PID_objective (x); % cost function
 
 nVar = 3; % Number of unknown variables

 varSize = [1 nVar]; % matrix size of unknwon variables

 
 minkp=kp-rand;
 maxkp=kp+rand;
 
 minki=ki-rand;
 maxki=ki+rand;
 
 minkd=kd-rand;
 maxkd=kd+rand;
 
rmin=min(kp,ki);
rmax=max(kp,ki);
 
%VelMinkp=0.2*(maxkp-minkp);
 %VelMaxkp=-VelMinkp;
 
 %VelMinki=0.2*(maxki-minki);
 %VelMaxki=-VelMinki;
 
 
%VelMaxkd=0.2*(maxkd-minkd);
% VelMinkd=-VelMaxkd;
 

%% Parameters of PSO

% Constriction Coefficients
kappa = 1;
phi1 = 2.05;
phi2 = 2.05;
phi = phi1 + phi2;
chi = 2*kappa/abs(2-phi-sqrt(phi^2-4*phi));
wmin=0.1;
wmax=1.2;


nPop = 10; % Population size

%w = chi; % Inertia ceofficient
w=1.2;
wdamp=0.05; % damping ratio of inertia ceofficient
%c1 = chi*phi1; % personal acceleration coefficient
%c2 = chi*phi2; % Social acceleration ceofficient
c1=2;
c2=2;
%% Initialization 
% The particle template
empty_particle.Position = [];
empty_particle.Velocity = [];
empty_particle.Cost = [];
empty_particle.Best.Position = [];
empty_particle.Best.Cost = [];

% create population array
particle = repmat(empty_particle, nPop, 1);
% initialize global best

GlobalBest.Cost = inf;


% initialize population array
for i=1:nPop
   % generate random solution
    particle(i).Position(1,1) = unifrnd(minkp, maxkp, 1);
    particle(i).Position(1,2) = unifrnd(minki, maxki, 1);
    particle(i).Position(1,3) = unifrnd(minkd, maxkd, 1);
    % initilize velocity
    particle(i).Velocity = zeros(varSize);
    % evaluation
    particle(i).Cost=CostFunction(particle(i).Position);
    % update the personal best
    particle(i).Best.Position = particle(i).Position;
    particle(i).Best.Cost = particle(i).Cost;
    % update global best 
    if particle(i).Best.Cost < GlobalBest.Cost
        GlobalBest = particle(i).Best;
    
    end
   particle(i).velmax=zeros(varSize);

end
% store the best array om each iteration


%% Main loop of PSO
for it=1:MaxIt
  
    for i=1:nPop
       
        % update velocity
        particle(i).Velocity = w*particle(i).Velocity...
            + c1*rand(varSize).*(particle(i).Best.Position - particle(i).Position)...
           +c2*rand(varSize).*(GlobalBest.Position - particle(i).Position);
        


   %  particle(i).Velocity= max(abs(particle(i).Velocity),0.1);
 % particle(i).Velocity= min(abs(particle(i).Velocity),0.08);
      
  
        % update position
     particle(i).Position = particle(i).Position+particle(i).Velocity;
     
 %if particle(i).Position(1,1)>32
%       particle(i).Position(1,1)= rand;
%  end
%  if particle(i).Position(1,2)>28
%     particle(i).Position(1,2)=rand;
%  end
    
% if particle(i).Position(1,3)>0.5
%  particle(i).Position(1,3)= rand;
 % end
 % if particle(i).Position(1,1)<0
 %   particle(i).Position(1,1)=rand;
 % end
 % if particle(i).Position(1,2)<0
 %   particle(i).Position(1,2)=rand;
 % end
 %  if particle(i).Position(1,3)<0
 %   particle(i).Position(1,3)=rand;
 % end
  
 %   particle(i).Position = max(particle(i).Position, rmin);
 %particle(i).Position = min(particle(i).Position,rmax);
 particle(i).Position(1,1) = max(particle(i).Position(1,1), 0);
 % particle(i).Position(1,1) = min(particle(i).Position(1,1), 10);
        
 particle(i).Position(1,2) = max(particle(i).Position(1,2), 0);
 % particle(i).Position(1,2) = min(particle(i).Position(1,2), 10);
         
 particle(i).Position(1,3) = max(particle(i).Position(1,3),0);
 %particle(i).Position(1,3) = min(particle(i).Position(1,3), 0.5);
         
        % evaluation
        particle(i).Cost=CostFunction(particle(i).Position);
        % Update personal best
        if particle(i).Cost < particle(i).Best.Cost   
            particle(i).Best.Position=particle(i).Position;
            particle(i).Best.Cost = particle(i).Cost;
            % update global best
            if particle(i).Best.Cost < GlobalBest.Cost
                 GlobalBest = particle(i).Best;
            end
        end
        % store the best cost value
        BestCosts(it)=GlobalBest.Cost;
        
                  
    end
     disp(['Iteration=' num2str(it) '; Best Cost=' num2str(BestCosts(it))]) ;
    % damping Inertia coefficient
    
    a=it/MaxIt;
    b=1-a;
   % w=wmax-(wmax-wmin)*a;
 c1=2.1+1.8*b;
 c2=0.1+1.8*a;
 w=wmax*b;
  % w=w*wdamp;
end
fpso=BestCosts;
%% Results
figure;
plot(BestCosts,'.');
xlabel('Iteration');
ylabel('Best Cost');
kp=GlobalBest.Position(1,1);
ki=GlobalBest.Position(1,2);
kd=GlobalBest.Position(1,3);
end