function Z=new_dc_pram_4pram(x)
%km=x(1);
%L=x(2);
%R=x(3);
%Jr=x(4);
%m1=x(5);
%d1=x(6);
%Jsh=x(7);
%m2=x(8);
%Br=x(9);
%Bsh=x(10);
%kb=x(11);
%I1=x(12);
%I2=x(14);
%d2=x(15);

%kg=8;
%l=0.41;
%g=9.81;

ang1=load('ang_hip_6v');ang1=cell2mat(struct2cell(ang1));

ang2=load('ang_hip_8v');ang2=cell2mat(struct2cell(ang2));
dt=0.01;
t=0:dt:5;
u1(1:1,1:501)=-6;

u2(1:1,1:501)=-8;
%b=km*kg;
%a11=L*(l^2*m2+d1^2*m1+Jr*kg^2+Jsh+I1);
%a12=R*(l^2*m2+d1^2*m1+Jr*kg^2+Jsh+I1)+L*(Br*kg^2+Bsh);
%a13=-l*g*L*m2-L*d1*g*m1+R*Br*kg^2+R*Bsh+kb*kg^2*km;
%a14=-R*(l*g*m2+d1*g*m1);
b=x(1);
a11=x(2);
a12=x(3);
a13=x(4);
a14=x(5);


s=tf('s');

plant=b/(a11*s^3+a12*s^2+a13*s+a14);

q1=lsim(plant,u1,t);

q2=lsim(plant,u2,t);
e1=ang1-q1;
e2=ang2-q2;
e1s=e1.^2;
e2s=e2.^2;
e1Sum=sum(e1s)/501;
e2Sum=sum(e2s)/501;
Z=(sqrt(e1Sum)+sqrt(e2Sum))/2;

%e1ave=sum(e1)/501;
%e2ave=sum(e2)/501;
%Z=abs((e1ave+e2ave)/2);


%e=(e1+e2)/2;

%Z=sum(abs(e));
%Z=sum(t'.*abs(e)*dt);
%Z= trapz(t,abs(e));
%Z= trapz(t, t'.*abs(e));


end