function [b,a11,a12,a13,a14,fval]=hip_ga_new_4param(initpop,gen)

opts=optimoptions('ga','PopulationSize',50,'Display','iter','Generations',gen,'InitialPopulation',initpop,...
    'PlotFcns',@myplot);

x=ga(@(x) new_dc_pram_4pram(x),5,[],[],[],[],[0 0.001 0 0 0],[],[],opts);


 % simple plot function
    function state= myplot(options,state,flag)
        fval=state.Best';
        disp(state.Population);
       
    end
b=x(1);
a11=x(2);
a12=x(3);
a13=x(4);
a14=x(5);
end